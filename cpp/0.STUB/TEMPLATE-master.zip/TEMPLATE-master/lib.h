// lib.h

void foo(int);

template<typename T> 
T square(T a);