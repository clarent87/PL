// main.cpp
#include "lib.h"

int main()
{
	foo(3);
	square(3);
}