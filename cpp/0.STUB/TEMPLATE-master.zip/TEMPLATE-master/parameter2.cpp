/*
* HOME       : ecourse.co.kr
* EMAIL      : smkang @ codenuri.co.kr
* COURSENAME : C++ Template Programming
* MODULE     : parameter2.cpp
* Copyright (C) 2017 CODENURI Inc. All rights reserved.
*/

// type parameter
template<typename T> class List
{
};

int main()
{
	list<int> s1;
}