// lib.cpp

void foo(int a)
{
}

template<typename T> T square(T a)
{
	T ret = a * a;
	return ret;
}